package parcial1_321;


public class Coral extends EspecieMarina implements Alimentados{
    private double profundidadIdeal;

    //CONSTRUCTOR
    public Coral(String nombre, String tanqueUbicacion, TipoAgua tipoAgua, double profundidadIdeal) {
        super(nombre, tanqueUbicacion, tipoAgua);
        this.profundidadIdeal = profundidadIdeal;
        validarProfundidadIdeal();
    }
    
    
    //METODO PARA VALIDAR
    private void validarProfundidadIdeal(){
        if(profundidadIdeal <= 0){
            throw new IllegalArgumentException("Profundidad incorrecta");
        }
    }
    
    //METODO PARA ALIMENTAR
    @Override
    public String Alimentar(){
        return getNombre() + " ALIMENTADO";
    }
    
    //METODO PARA REPRODUCIRSE
    @Override
    public String reproducirse(){
        return getNombre() + " SE REPRODUJO";
    }
    
    
    //METODO PARA RESPIRAR
    public String respirar(){
        return getNombre() + " RESPIRANDO";
    }

    
    //METODO TOSTRING
    @Override
    public String toString() {
        return  super.toString() +  "profundidadIdeal =" + profundidadIdeal ;
    }
    
    
    //METODO PARA MOVERSE
    @Override
    public String moverEspecie(){
        return getNombre() + " NO ES MOVIBLE";
    }
}
