package parcial1_321;


public class Pez extends EspecieMarina implements Alimentados{
    private double longitudMaxima;
    
    
    //CONSTRUCTOR
    public Pez(String nombre, String tanqueUbicacion, TipoAgua tipoAgua,double longitudMaxima) {
        super(nombre, tanqueUbicacion, tipoAgua);
        this.longitudMaxima = longitudMaxima;
        validarLongitud();
    }

    
    //METODO PARA VALIDAR
    private void validarLongitudMaxima(){
        if(longitudMaxima < 1 || longitudMaxima > 100){
            throw new IllegalArgumentException("Longitud incorrecta");
        }
    }
    
    
    //METODO PARA ALIMENTAR
    @Override
    public String Alimentar(){
        return getNombre() + " ALIMENTADO";
    }
    
    
    //VALIDACION
    private void validarLongitud(){
        if (this.longitudMaxima<0 || this.longitudMaxima>100)
            throw new IllegalArgumentException("Longitud invalida");
    }
    
    
    
    //METODO PARA REPRODUCIRSE
    @Override
    public String reproducirse(){
        return getNombre() + " SE REPRODUJO";
    }
    
    
    //METODO PARA RESPIRAR
    public String respirar(){
        return getNombre() + " RESPIRANDO";
    }

    
    //METODO TOSTRING
    @Override
    public String toString() {
        return  super.toString() + "longitudMaxima=" + longitudMaxima;
    }

    //METODO PARA MOVERSE
    @Override
    public String moverEspecie(){
        return getNombre() + " FUE MOVIDO";
    }
    
    
    
}
