package parcial1_321;


public class EspecieRepetidaException extends Exception {
    public EspecieRepetidaException (String mensaje){
        super(mensaje);
    }
}
