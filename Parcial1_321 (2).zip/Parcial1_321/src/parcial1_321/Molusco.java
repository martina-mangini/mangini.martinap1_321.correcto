package parcial1_321;


public class Molusco extends EspecieMarina {
    private String tipoConcha;

    
    //CONSTRUCTOR
    public Molusco(String nombre, String tanqueUbicacion, TipoAgua tipoAgua, String tipoConcha) {
        super(nombre, tanqueUbicacion, tipoAgua);
        this.tipoConcha = tipoConcha;
        validarTipoConcha();
    }
    
    //METODO PARA VALIDAR
    private void validarTipoConcha(){
        if(tipoConcha == null || tipoConcha.isBlank() || tipoConcha.isEmpty()){
            throw new IllegalArgumentException("Tipo de concha incorrecta");
        }
    }
    
    
   //METODO PARA REPRODUCIRSE
    @Override
    public String reproducirse(){
        return getNombre() + " SE REPRODUJO";
    }
    
    
    //METODO PARA RESPIRAR
    public String respirar(){
        return getNombre() + " RESPIRANDO";
    }

    
    //METODO TOSTRING
    @Override
    public String toString() {
        return super.toString() + "tipoConcha=" + tipoConcha ;
    }
    
    //METODO PARA MOVERSE
    @Override
    public String moverEspecie(){
        return getNombre() + " FUE MOVIDO";
    }
    
    
    
}
