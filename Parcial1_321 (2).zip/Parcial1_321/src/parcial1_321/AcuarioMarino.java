package parcial1_321;

import java.util.ArrayList;

public class AcuarioMarino {
    private ArrayList<EspecieMarina> especies;

    
    //CONSTRUCTOR
    public AcuarioMarino() {
        this.especies = new ArrayList<>();
    }
    
    
    //METODO PARA AGREGAR ESPECIE
    public void agregarEspecie(EspecieMarina especie) throws EspecieRepetidaException {
        if (especies.contains(especie)){
            throw new EspecieRepetidaException("Ya existe una especie con ese nombre y ubicacion");
        }
        especies.add(especie);
    }
    
    
    //METODO PARA MOSTRAR ESPECIES SIN PASARLE NADA
    public String mostrarEspecies(){
        StringBuilder sb = new StringBuilder();
        sb.append("ESPECIES REGISTRADAS: \n");
        for(EspecieMarina em : especies){
            sb.append(em.toString() + '\n');
        }
        return sb.toString();
    }
    
    
    //METODO PARA MOSTRAR ESPECIES PASANDOLE UNA LISTA
    public String mostrarEspecies(ArrayList<EspecieMarina> lista){
        StringBuilder sb = new StringBuilder();
        sb.append("ESPECIES FILTRADAS: \n");
        for(EspecieMarina em : lista){
            sb.append(em.toString() + '\n');
        }
        return sb.toString();
    }
    
    
    //METODO PARA FILTRAR POR TIPO DE AGUA
    public ArrayList<EspecieMarina> filtrarPorAgua (TipoAgua tipo){
        ArrayList<EspecieMarina> listaFiltrada = new ArrayList<>();
        for(EspecieMarina em : especies){
            if (em.getTipoAgua().equals(tipo)){
                listaFiltrada.add(em);
            }
        }
        return listaFiltrada;
    }
    
    
    
    //METODO PARA MOVER TODAS LAS ESPECIES
    public void moverEspecies(){
        System.out.println("\n-------MOVIENDO ESPECIES-------");
        for (EspecieMarina em : especies){
            System.out.println(em.moverEspecie());
        }
    }
    
    
    
    //METODO PARA REALIZAR LAS FUNCIONES BIOLOGICAS
    public String realizarFuncionesBiologicas(){
        StringBuilder sb = new StringBuilder();
        sb.append("\n-------FUNCIONES BIOLOGICAS------- \n");
        for (EspecieMarina em : especies){
            sb.append(em.respirar()).append('\n');
            if (em instanceof Alimentados){
                sb.append(((Alimentados) em).Alimentar()).append('\n');
            }
        }
        return sb.toString();
    }
    
    
    
    
    
}
