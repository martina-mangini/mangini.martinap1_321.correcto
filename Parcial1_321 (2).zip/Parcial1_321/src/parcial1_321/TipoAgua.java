package parcial1_321;


public enum TipoAgua {
    AGUA_SALADA,
    AGUA_DULCE
}
