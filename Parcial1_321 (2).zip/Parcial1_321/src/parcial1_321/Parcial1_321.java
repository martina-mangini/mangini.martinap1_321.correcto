package parcial1_321;


public class Parcial1_321 {

    
    public static void main(String[] args) {
     
        AcuarioMarino MundoMarino = new AcuarioMarino();
        
        try{
            Pez pescado1 = new Pez("Salmon", "Tanque1", TipoAgua.AGUA_SALADA, 60);
            Molusco molusco1 = new Molusco("Molusquito", "Tanque5", TipoAgua.AGUA_DULCE, "Espiralada");
            Coral coral1 = new Coral("Coralcito", "Tanque10", TipoAgua.AGUA_SALADA, 100);
            Coral coral2 = new Coral("Coralcito", "Tanque10", TipoAgua.AGUA_SALADA, 100); //ELEMENTO REPETIDO PARA VERIFICAR ERROR
            
            MundoMarino.agregarEspecie(pescado1);
            MundoMarino.agregarEspecie(molusco1);
            MundoMarino.agregarEspecie(coral1);
            MundoMarino.agregarEspecie(coral2);
            
           
        }catch (EspecieRepetidaException ex){
            System.out.println("ERROR: " + ex.getMessage() + '\n');
        }
        
        System.out.println(MundoMarino.mostrarEspecies());
        System.out.println(MundoMarino.mostrarEspecies(MundoMarino.filtrarPorAgua(TipoAgua.AGUA_SALADA)));

        MundoMarino.moverEspecies();
        System.out.println(MundoMarino.realizarFuncionesBiologicas());
        
        
        
        
    }
    
}
