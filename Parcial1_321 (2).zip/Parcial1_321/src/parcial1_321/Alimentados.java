package parcial1_321;


public interface Alimentados {
   
    public abstract String Alimentar();
}
